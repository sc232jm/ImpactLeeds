/* Utilising: https://cookieconsent.orestbida.com/ */
/* Obtained from: https://stackblitz.com/edit/web-platform-ahqgz3?file=index.js,index.html,en.json demo project */

const im = iframemanager();

im.run({
    onChange: ({changedServices, eventSource}) => {
        if (eventSource.type === 'click') {
            const servicesToAccept = [
                ...CookieConsent.getUserPreferences().acceptedServices['analytics'],
                ...changedServices,
            ];

            CookieConsent.acceptService(servicesToAccept, 'analytics');
        }
    },

    currLang: 'en',

});

CookieConsent.run({
    guiOptions: {
        consentModal: {
            layout: 'box inline',
            position: 'bottom left',
            equalWeightButtons: true,
            flipButtons: false,
        },
        preferencesModal: {
            layout: 'box',
            equalWeightButtons: true,
            flipButtons: false,
        },
    },

    categories: {
        necessary: {
            readOnly: true,
            enabled: true,
        },

        analytics: {},
    },

    language: {
        default: 'en',

        translations: {
            en: '/static/js/en.json',
        },
    },
});


// Initialize CookieConsent and IframeManager
window.addEventListener('load', function () {
    const im = iframemanager();
    im.run({
        onChange: ({changedServices, eventSource}) => {
            if (eventSource.type === 'click') {
                const servicesToAccept = [
                    ...CookieConsent.getUserPreferences().acceptedServices['analytics'],
                    ...changedServices,
                ];

                CookieConsent.acceptService(servicesToAccept, 'analytics');
            }
        },

        currLang: 'en',

        services: {
            youtube: {
                embedUrl: 'https://www.youtube-nocookie.com/embed/{data-id}',
                thumbnailUrl: 'https://i3.ytimg.com/vi/{data-id}/hqdefault.jpg',

                iframe: {
                    allow:
                        'accelerometer; encrypted-media; gyroscope; picture-in-picture; fullscreen;',
                },

                languages: {
                    en: {
                        notice:
                            'This content is hosted by a third party. By showing the external content you accept the <a rel="noreferrer noopener" href="https://www.youtube.com/t/terms" target="_blank">terms and conditions</a> of youtube.com.',
                        loadAllBtn: 'Accept and Load',
                    },
                },
            },

            vimeo: {
                embedUrl: 'https://player.vimeo.com/video/{data-id}',
                iframe: {
                    allow: 'fullscreen; picture-in-picture;',
                },

                thumbnailUrl: async (dataId, setThumbnail) => {
                    const url = `https://vimeo.com/api/v2/video/${dataId}.json`;
                    const response = await (await fetch(url)).json();
                    const thumbnailUrl = response[0]?.thumbnail_large;
                    thumbnailUrl && setThumbnail(thumbnailUrl);
                },

                languages: {
                    en: {
                        notice:
                            'This content is hosted by a third party. By showing the external content you accept the <a rel="noreferrer noopener" href="https://vimeo.com/terms" target="_blank">terms and conditions</a> of vimeo.com.',
                        loadBtn: 'Load once',
                        loadAllBtn: "Don't ask again",
                    },
                },
            },
        },
    });

    CookieConsent.run({
        guiOptions: {
            consentModal: {
                layout: 'box inline',
                position: 'bottom left',
                equalWeightButtons: true,
                flipButtons: false,
            },
            preferencesModal: {
                layout: 'box',
                equalWeightButtons: true,
                flipButtons: false,
            },
        },

        categories: {
            necessary: {
                readOnly: true,
                enabled: true,
            },

            analytics: {
                services: {
                    youtube: {
                        label: 'Youtube Embed',
                        onAccept: () => im.acceptService('youtube'),
                        onReject: () => im.rejectService('youtube'),
                    },
                    vimeo: {
                        label: 'Vimeo Embed',
                        onAccept: () => im.acceptService('vimeo'),
                        onReject: () => im.rejectService('vimeo'),
                    },
                },
            },

            ads: {},
        },

        language: {
            default: 'en',

            translations: {
                en: '/static/js/en.json',
            },
        },
    });
});